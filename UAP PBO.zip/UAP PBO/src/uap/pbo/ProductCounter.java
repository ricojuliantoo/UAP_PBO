/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uap.pbo;

/**
 *
 * @author LENOVO
 */
public interface ProductCounter {
    public double TAX=0.0;
    public void hitungJumlahProduk();
    public void hitungHargaProduk();
}
